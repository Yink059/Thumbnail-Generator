YinkTNG
/////////////////////////////////////////
By: Yink
Email: b.d.sandford@gmail.com
Reddit: Yink059
Discord: Yink#0312
/////////////////////////////////////////

Yink's Thumbnail Generator

use: create simple thumbnails for youtube videos

just run YinkTNG.jar

default text fields are filled with respective input names ( for example "left player" will be displayed on the left under the icon)
the number next to these are font point sizes

"Helvetica" is just the default font name that I inputed. just put a font name there that you have installed(case sensitive).

the overlay is put over both character renders and the background.

the background image can be any size but is automatically scaled to 1280x720, so for best results have your BG image that size.

the character images are scaled to either 400px by width/heigth ratio if its landscape or 350px by heigth/width if its portrait.
this means those files can be any size.

the directory \YinkTN is where it will default to when looking for files.
it will output a new file to "\YinkTN\saved" when you click "Save Current..." or "Preview..."
"Save Current..." will either overwrite a file with the same name or make a new file.
"Preview..." will just over "temp.png" in "\YinkTN\saved"

VERY IMPORTANT: DO NOT INCLUDE PERIODS(.), COLONS(:), OR BACKSLASHES(\) IN YOUR TEXTFIELDS. THE PROGRAM WILL NOT WRITE THE FILE CORRECTLY.

/////////////////////////////////////////

feel free to send me questions/suggestions or tell me how much of a piece of shit this program is
both are acceptable and understandable~

/////////////////////////////////////////

changelog:
v2-
added adjustors to image size and adjustors for positioning of image elements

